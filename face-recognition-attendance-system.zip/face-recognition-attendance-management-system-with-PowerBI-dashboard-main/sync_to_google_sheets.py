import sqlite3
import gspread
from google.oauth2.service_account import Credentials

# Path to your Google service account credentials JSON file
SERVICE_ACCOUNT_FILE = 'credentials/service_account.json'

# Scopes required to update Google Sheets
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# ✅ Your actual Google Sheet URL
SPREADSHEET_URL = 'https://docs.google.com/spreadsheets/d/1QsYLohhtHjglKl3PigRFdbdiSE6iaqJi_7yO7CozMyw/edit?usp=sharing'

def sync_to_google_sheets():
    # Connect to SQLite DB and fetch attendance records
    conn = sqlite3.connect('information.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT NAME, Time, Date FROM Attendance ORDER BY Date, Time")
    rows = cursor.fetchall()
    conn.close()

    # Prepare data with header row
    data = [["NAME", "TIME", "DATE"]]
    for row in rows:
        data.append([row['NAME'], row['Time'], row['Date']])

    # Authenticate with Google Sheets API
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    client = gspread.authorize(creds)

    # ✅ Open spreadsheet using full URL
    spreadsheet = client.open_by_url(SPREADSHEET_URL)

    # Try to open the worksheet named "AttendanceData", create if it doesn't exist
    try:
        sheet = spreadsheet.worksheet("AttendanceData")
    except gspread.exceptions.WorksheetNotFound:
        sheet = spreadsheet.add_worksheet(title="AttendanceData", rows="100", cols="20")

    # Clear existing content and update with new data
    sheet.clear()
    sheet.update(values=data, range_name='A1')


    print("✔ Synced to Google Sheet successfully.")

# For testing outside Flask:
if __name__ == "__main__":
    sync_to_google_sheets() # type: ignore
