import json
from flask import Flask, render_template, request, session, redirect, url_for
import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime, date
import sqlite3
import sync_to_google_sheets  # your sync module

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a secure random key

@app.route('/new', methods=['GET', 'POST'])
def new():
    if request.method == "POST":
        return render_template('index.html')
    else:
        return "Everything is okay!"

@app.route('/name', methods=['GET', 'POST'])
def name():
    if request.method == "POST":
        name1 = request.form['name1']

        cam = cv2.VideoCapture(0) # type: ignore
        while True:
            ret, frame = cam.read()
            if not ret:
                break
            cv2.imshow("Press Space to capture image", frame) # type: ignore

            k = cv2.waitKey(1) # type: ignore # type: ignore
            if k % 256 == 27:  # ESC to quit
                break
            elif k % 256 == 32:  # SPACE to capture
                img_name = f"{name1}.png"
                path = 'Training images'
                if not os.path.exists(path):
                    os.makedirs(path)
                cv2.imwrite(os.path.join(path, img_name), frame) # type: ignore
                print(f"{img_name} written!")
                break

        cam.release()
        cv2.destroyAllWindows() # type: ignore

        # Sync data to Google Sheets after capturing image
        sync_to_google_sheets.sync_to_google_sheet() # type: ignore

        return render_template('image.html')
    else:
        return 'All is not well'

@app.route("/", methods=["GET", "POST"])
def recognize():
    if request.method == "POST":
        path = 'Training images'
        images = []
        classNames = []
        myList = os.listdir(path)
        for cl in myList:
            curImg = cv2.imread(f'{path}/{cl}') # type: ignore
            images.append(curImg)
            classNames.append(os.path.splitext(cl)[0])

        def findEncodings(images):
            encodeList = []
            for img in images:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) # type: ignore # type: ignore
                encode = face_recognition.face_encodings(img)
                if not encode:
                    print("Image can't be encoded")
                    continue
                encodeList.append(encode[0])
            return encodeList

        def markData(name):
            now = datetime.now()
            dtString = now.strftime('%H:%M')
            today = date.today()
            conn = sqlite3.connect('information.db')
            conn.execute('''CREATE TABLE IF NOT EXISTS Attendance
                            (NAME TEXT NOT NULL,
                             Time TEXT NOT NULL,
                             Date TEXT NOT NULL)''')
            conn.execute("INSERT INTO Attendance (NAME, Time, Date) VALUES (?, ?, ?)",
                         (name, dtString, today,))
            conn.commit()
            conn.close()

        def markAttendance(name):
            with open('attendance.csv', 'r+', errors='ignore') as f:
                myDataList = f.readlines()
                nameList = [line.split(',')[0] for line in myDataList]
                if name not in nameList:
                    now = datetime.now()
                    dtString = now.strftime('%H:%M')
                    f.writelines(f'\n{name},{dtString}')

        encodeListKnown = findEncodings(images)
        print('Encoding Complete')

        cap = cv2.VideoCapture(0) # type: ignore
        while True:
            success, img = cap.read()
            imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25) # type: ignore
            imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB) # type: ignore # type: ignore # type: ignore

            facesCurFrame = face_recognition.face_locations(imgS)
            encodesCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

            for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
                matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
                faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
                matchIndex = np.argmin(faceDis)

                if faceDis[matchIndex] < 0.50:
                    name = classNames[matchIndex].upper()
                    markAttendance(name)
                    markData(name)
                else:
                    name = 'Unknown'

                y1, x2, y2, x1 = faceLoc
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2) # type: ignore # type: ignore
                cv2.rectangle(img, (x1, y2 - 35), (x2, y2), (0, 255, 0), cv2.FILLED) # type: ignore # type: ignore # type: ignore
                cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2) # type: ignore

            cv2.imshow('Punch your Attendance', img) # type: ignore
            c = cv2.waitKey(1) # type: ignore
            if c == 27:
                break

        cap.release()
        cv2.destroyAllWindows() # type: ignore
        return render_template('first.html')
    else:
        return render_template('main.html')

@app.route('/login', methods=['POST'])
def login():
    json_data = json.loads(request.data.decode())
    username = json_data['username']
    password = json_data['password']
    import pandas as pd # type: ignore
    df = pd.read_csv('cred.csv')
    if username in df['username'].values:
        if df.loc[df['username'] == username, 'password'].values[0] == password: # type: ignore
            session['username'] = username
            return 'success'
    return 'failed'

@app.route('/checklogin')
def checklogin():
    if 'username' in session:
        return session['username']
    return 'False'

@app.route('/how', methods=["GET", "POST"])
def how():
    return render_template('form.html')

@app.route('/data', methods=["GET", "POST"])
def data():
    if request.method == "POST":
        today = date.today()
        conn = sqlite3.connect('information.db')
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT DISTINCT NAME, Time, Date FROM Attendance WHERE Date=?", (today,))
        rows = cur.fetchall()
        conn.close()
        return render_template('form2.html', rows=rows)
    else:
        return render_template('form1.html')

@app.route('/whole', methods=["GET", "POST"])
def whole():
    conn = sqlite3.connect('information.db')
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT NAME, Time, Date FROM Attendance")
    rows = cur.fetchall()
    conn.close()
    return render_template('form3.html', rows=rows)

@app.route('/dashboard', methods=["GET", "POST"])
def dashboard():
    return render_template('dashboard.html')

@app.route('/sync', methods=['POST'])
def sync():
    sync_to_google_sheets.sync_to_google_sheet() # type: ignore
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(debug=True)
